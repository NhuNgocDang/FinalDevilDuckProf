<?php
    require "db_connect.php";
?>
<!doctype html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>advancedSearch</title>
</head>
<body>
<fieldset>
    <table>
        <form action="search.php" method="post">
        <tr>
            <td><span>Company name Length</span></td>
            <td><select name="length" id="length">
                    <option value=""></option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                    <option value="13">13</option>
                    <option value="14">14</option>
                    <option value="15">15</option>
                    <option value="16">16</option>
                    <option value="17">17</option>
                    <option value="18">18</option>
                    <option value="19">19</option>
                    <option value="20">20</option>
                    <option value="21">21</option>
                    <option value="22">22</option>
                    <option value="23">23</option>
                    <option value="24">24</option>
                    <option value="25">25</option>
                    <option value="26">26</option>
                    <option value="27">27</option>
                    <option value="28">28</option>
                    <option value="29">29</option>
                    <option value="30">30</option>
                    <option value="31">31</option>
                    <option value="32">32</option>
                </select></td>
        </tr>
        <tr>
            <td><span>Region</span></td>
            <td>
                <select name="region" id="region">
                    <option value=""></option>
                    <?php
                        $sql="select address from Address";
                        $r=mysqli_query($connection,$sql);
                        while ($row=mysqli_fetch_array($r)){
                            echo "<option value=".$row['address'].">".$row['address']."</option>";
                        }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td><span>Industry</span></td>
            <td>
                <select name="industry" id="">
                    <option value=""></option>
                    <option value="Retail Trade">Retail Trade</option>
                    <option value="Arts">Arts</option>
                    <option value="Contruction">Contruction</option>
                    <option value="Information">Information</option>
                    <option value="Health Care and Social Assistance">Health Care and Social Assistance</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>
                <button type="submit">advanced search</button>
            </td>
        </tr>
        </form>
    </table>
</fieldset>

</body>
</html>